﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Entities
{
    public class MenuSite
    {
        public string Descricao { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }
        public string UrlImagem { get; set; }
        public string IdCampo { get; set; }
    }
}
