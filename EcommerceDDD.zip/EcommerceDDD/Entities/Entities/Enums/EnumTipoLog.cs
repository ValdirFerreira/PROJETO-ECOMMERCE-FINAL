﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Entities.Entities.Enums
{
    public enum EnumTipoLog
    {
        Erro = 0,
        Informativo = 1
    }
}
